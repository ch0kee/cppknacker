using System;
using System.Collections.Generic;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Threading;

namespace GrafSzelBe
{
    //////////////////////////////////////////////////////////////////////////
    // Cs�csok oszt�lya
    class Cs�cs
    {
        public Cs�cs(Point pt, char name)
        {
            m_Pont = pt;
            m_N�v = name;
        }

        public void rajzol(Graphics g)
        {
            const int PONT_�TM�R� = 6;
            using (SolidBrush b = new SolidBrush(m_Sz�n))
            {
                g.FillEllipse(b, m_Pont.X - PONT_�TM�R� / 2, m_Pont.Y - PONT_�TM�R� / 2, PONT_�TM�R�, PONT_�TM�R�);
                g.DrawString(m_N�v.ToString(), new Font("Arial", 10, FontStyle.Bold), b, m_Pont.X - 3, m_Pont.Y + 3);

                foreach (Cs�cs cs in m_Szomsz�dok)
                    (new �l(this,cs)).rajzol(g);
            }
        }

        public Point Pont { get { return m_Pont; } set { m_Pont = value; } }
        public char N�v { get { return m_N�v; } }
        public Color Sz�n { get { return m_Sz�n; } set { m_Sz�n = value; } }
        public int d { get { return m_d; } set { m_d = value; } }
        public Cs�cs P { get { return m_P; } set { m_P = value; } }

        Color m_Sz�n = Color.Blue;
        Point m_Pont;
        char m_N�v;
        int m_d = -1;   // kezd�st�l vett t�vols�g
        Cs�cs m_P = null;   // �scs�cs

        
        public void �sszek�t( Cs�cs cs )
        {
            m_Szomsz�dok.Add(cs);
        }

        public List<Cs�cs> Szomsz�dok { get { return m_Szomsz�dok; } }

        List<Cs�cs> m_Szomsz�dok = new List<Cs�cs>();   // c�lok
    }
    //////////////////////////////////////////////////////////////////////////
    // �lek oszt�lya
    class �l
    {
        public �l(Cs�cs kezd�cs�cs, Cs�cs v�gcs�cs)
        {
            m_Kezd�cs�cs = kezd�cs�cs;
            m_V�gcs�cs = v�gcs�cs;
        }
        public void rajzol(Graphics g)
        {
            using (Pen p = new Pen(m_�LSZ�N))
            {
                g.DrawLine(p, m_Kezd�cs�cs.Pont, m_V�gcs�cs.Pont);
                rajzolnyilat(g, p);
            }
        }
        void rajzolnyilat(Graphics g, Pen p)
        {
            GraphicsState gs = g.Save();
            float x = m_V�gcs�cs.Pont.X - m_Kezd�cs�cs.Pont.X;
            float y = m_V�gcs�cs.Pont.Y - m_Kezd�cs�cs.Pont.Y;
            g.TranslateTransform(m_V�gcs�cs.Pont.X, m_V�gcs�cs.Pont.Y);
            double rotation = Math.Atan(-y / x);
            float addition = (x >= 0 ? 180 : 0);
            //addition += (y > 0  ? 180 : 0);// +(x < 0 ? 180 : 0);
            g.RotateTransform(-(float)(rotation * 180.0 / Math.PI) + addition);// + (x > 0 ? 180 : 0));
            g.DrawLine(p, 0.0f, 0.0f, 10.0f, -4.0f);
            g.DrawLine(p, 0.0f, 0.0f, 10.0f, 4.0f);
            g.Restore(gs);
        }

        Cs�cs m_Kezd�cs�cs;
        Cs�cs m_V�gcs�cs;
        static readonly Color m_�LSZ�N = Color.Blue;
    }
    //////////////////////////////////////////////////////////////////////////
    // Gr�f oszt�ly
    class Graf
    {
        // gr�f adatf�jl pl.
        // cs�cs megad�sa : A=(10,20)
        // �l megad�sa : A->B

        public bool Bet�ltGr�fot(string filename, PictureBox pbox, ToolStripStatusLabel sbar)
        {
            m_StatusBar = sbar;
            m_RajzTer�let = pbox;
            Cs�csok.Clear();
            using (StreamReader r = new StreamReader(filename))
            {
                int minx = 0, miny = 0, maxx = 0, maxy = 0;   // rajzter�let meghat�roz�s�hoz
                string line;
                while((line = r.ReadLine()) != null)
                {
                    // eld�ntj�k, hogy �l vagy cs�cs
                    if (line.Length >= 7 && line.Substring(1,2) == "=(" && line.EndsWith(")"))  //cs�cs
                    {
                        int nyit�Z�r�jel = line.IndexOf('(');
                        int cs�k�Z�r�jel = line.LastIndexOf(')');
                        int Vessz� = line.IndexOf(',');
                        if (nyit�Z�r�jel != -1 && nyit�Z�r�jel < Vessz� && Vessz� < cs�k�Z�r�jel)
                        {
                            int x = Convert.ToInt32(line.Substring(nyit�Z�r�jel + 1, Vessz� - nyit�Z�r�jel - 1));
                            int y = Convert.ToInt32(line.Substring(Vessz� + 1, cs�k�Z�r�jel - Vessz� - 1));

                            if (Cs�csok.Count == 0)
                            {// els� elem
                                minx = x; maxx = x;
                                miny = y; maxy = y;
                            }
                            else
                            {
                                if (x < minx) minx = x;
                                if (x > maxx) maxx = x;
                                if (y < miny) miny = y;
                                if (y > maxy) maxy = y;
                            }

                            char c = line[0]; // n�v
                            Cs�csok.Add(new Cs�cs(new Point(x, y), c));
                        }
                    } else if (line.Length == 4 && line.Substring(1,2) == "->") //�l
                    {
                        // kikeress�k a kezd� �s v�gpontot
                        Cs�cs kezd�cs�cs = KeresCs�csot(line[0]);
                        Cs�cs v�gcs�cs = KeresCs�csot(line[3]);

                        if (kezd�cs�cs != null && v�gcs�cs != null)
                            kezd�cs�cs.�sszek�t(v�gcs�cs);
                    }
                }
                // rajzt�bla sz�l�n kihagy�s
                const int KERET = 40;
                minx -= KERET; miny -= KERET;
                maxx += KERET; maxy += KERET;
                // virtu�lis rajzt�bla m�rete
                int dy = Math.Abs(maxy - miny);
                int dx = Math.Abs(maxx - minx);
                // ar�nyok
                double xrate = (double)m_RajzTer�let.Width / dx;
                double yrate = (double)m_RajzTer�let.Height / dy;
                // cs�csok transzform�l�sa, m�retar�nyosan
                foreach (Cs�cs cs in Cs�csok)
                    cs.Pont = new Point(Convert.ToInt32((cs.Pont.X-minx) * xrate), Convert.ToInt32((cs.Pont.Y-miny) * yrate));
            }
            m_RajzTer�let.Invalidate();
            return Cs�csok.Count != 0;
        }
        // cs�cs visszaad�sa n�v alapj�n
        Cs�cs KeresCs�csot( char name )
        {
            foreach (Cs�cs cs in Cs�csok)
                if (cs.N�v == name)
                    return cs;
            return null;
        }
        // cs�csok �s kimen� �leinek kirajzol�sa
        public void RajzolCs�csokat(PaintEventArgs e)
        {
            foreach (Cs�cs cs in Cs�csok)
                cs.rajzol(e.Graphics);
        }
        //////////////////////////////////////////////////////////////////////////
        // sz�lf�ggv�ny az anim�ci�hoz
        public void Sz�less�giBej�r�s(object state)//char s)
        {
            if (m_Anim�ci�Fut)
                return;
            Color sz�ntelen = Color.Blue;
            Color sz�nes = Color.Red;
            m_Anim�ci�Fut = true;
            m_StatusBar.Text = "";

            Cs�cs start = KeresCs�csot((state as StarterForm).Kezd�cs�cs);
            if (start == null)
            {
                m_Anim�ci�Fut = false;
                return;
            }
            //////////////////////////////////////////////////////////////////////////
            // inicializ�l�s
            foreach (Cs�cs cs in Cs�csok)
            {
                cs.Sz�n = sz�ntelen;
                cs.P = null;
                cs.d = -1;
            }
            Sz�lkezel�s();
            //////////////////////////////////////////////////////////////////////////
            // els� elem sz�nez�se
            start.Sz�n = sz�nes;
            start.d = 0;
            //////////////////////////////////////////////////////////////////////////
            // sor inicializ�l�sa
            Queue<Cs�cs> Q = new Queue<Cs�cs>();
            Q.Enqueue(start);
            //////////////////////////////////////////////////////////////////////////
            // sor feldolgoz�sa
            while(Q.Count > 0)
            {
                Cs�cs cs�cs = Q.Dequeue();
                // ki�r�s
                m_StatusBar.Text += (cs�cs.N�v.ToString());
                Sz�lkezel�s();
                // szomsz�dok sorba helyez�se
                foreach (Cs�cs szomsz�d in cs�cs.Szomsz�dok)
                {
                    if (szomsz�d.Sz�n == sz�ntelen)
                    {
                        szomsz�d.Sz�n = sz�nes;
                        szomsz�d.d = cs�cs.d + 1;
                        szomsz�d.P = cs�cs;
                        Q.Enqueue(szomsz�d);
                    }
                }
            }
            m_StatusBar.Text += " - K�sz";
            //////////////////////////////////////////////////////////////////////////
            m_Anim�ci�Fut = false;
        }
        // akkor h�vjuk, amikor friss�teni kell a rajzter�letet
        void Sz�lkezel�s()
        {
            m_RajzTer�let.Invalidate();
            Thread.Sleep(2000);
        }

        public List<Cs�cs> Cs�csok { get { return m_Cs�cspontok; } }

        PictureBox  m_RajzTer�let;
        List<Cs�cs> m_Cs�cspontok = new List<Cs�cs>();
        ToolStripStatusLabel m_StatusBar;
        static bool m_Anim�ci�Fut = false;
    }
}
