using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace GrafSzelBe
{
    partial class StarterForm : Form
    {

        public StarterForm( List<Cs�cs> cs�csok ) : this()
        {
            m_Cs�csok = cs�csok;
        }

        public StarterForm()
        {
            InitializeComponent();
        }
        //////////////////////////////////////////////////////////////////////////
        // Inicializ�l�s
        private void KezdoValasztoForm_Load(object sender, EventArgs e)
        {
            if (m_Cs�csok.Count == 0)   // nem volt bet�lt�tt cs�cs
            {
                DialogResult = DialogResult.Ignore;
                Close();
                return;
            }
                
            foreach (Cs�cs cs in m_Cs�csok)
                cmbCs�csok.Items.Add(cs.N�v);
            cmbCs�csok.SelectedIndex = 0;
        }
        //////////////////////////////////////////////////////////////////////////
        // OnOK + Kezd�Cs�cs be�ll�t�sa
        private void KezdBej�r�st_Click(object sender, EventArgs e)
        {
            m_Kezd�Cs�cs = cmbCs�csok.Text[0];
        }

        List<Cs�cs> m_Cs�csok;
        char m_Kezd�Cs�cs;
        public char Kezd�cs�cs { get { return m_Kezd�Cs�cs; } }
    }
}