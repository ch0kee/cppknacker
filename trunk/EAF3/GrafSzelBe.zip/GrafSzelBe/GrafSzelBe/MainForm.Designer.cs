namespace GrafSzelBe
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.f�jlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gr�fAdatainakBet�lt�seToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sz�less�giBej�r�sToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.statusBar = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.f�jlToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(720, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // f�jlToolStripMenuItem
            // 
            this.f�jlToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gr�fAdatainakBet�lt�seToolStripMenuItem,
            this.sz�less�giBej�r�sToolStripMenuItem});
            this.f�jlToolStripMenuItem.Name = "f�jlToolStripMenuItem";
            this.f�jlToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.f�jlToolStripMenuItem.Text = "Gr�f";
            // 
            // gr�fAdatainakBet�lt�seToolStripMenuItem
            // 
            this.gr�fAdatainakBet�lt�seToolStripMenuItem.Name = "gr�fAdatainakBet�lt�seToolStripMenuItem";
            this.gr�fAdatainakBet�lt�seToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.gr�fAdatainakBet�lt�seToolStripMenuItem.Text = "Adatf�jl bet�lt�se...";
            this.gr�fAdatainakBet�lt�seToolStripMenuItem.Click += new System.EventHandler(this.gr�fAdatainakBet�lt�seToolStripMenuItem_Click);
            // 
            // sz�less�giBej�r�sToolStripMenuItem
            // 
            this.sz�less�giBej�r�sToolStripMenuItem.Enabled = false;
            this.sz�less�giBej�r�sToolStripMenuItem.Name = "sz�less�giBej�r�sToolStripMenuItem";
            this.sz�less�giBej�r�sToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.sz�less�giBej�r�sToolStripMenuItem.Text = "Sz�less�gi bej�r�s...";
            this.sz�less�giBej�r�sToolStripMenuItem.Click += new System.EventHandler(this.sz�less�giBej�r�sToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Cross;
            this.pictureBox1.Location = new System.Drawing.Point(23, 39);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(674, 391);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusBar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 446);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(720, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // statusBar
            // 
            this.statusBar.Name = "statusBar";
            this.statusBar.Size = new System.Drawing.Size(0, 17);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 468);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "Gr�f sz�less�gi bej�r�sa";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem f�jlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gr�fAdatainakBet�lt�seToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem sz�less�giBej�r�sToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel statusBar;
    }
}

