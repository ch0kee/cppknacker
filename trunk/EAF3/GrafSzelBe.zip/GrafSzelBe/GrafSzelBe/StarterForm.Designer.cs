namespace GrafSzelBe
{
    partial class StarterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cmbCs�csok = new System.Windows.Forms.ComboBox();
            this.btnKezdBej�r�st = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "V�laszd ki, melyik legyen az indul� cs�cs";
            // 
            // cmbCs�csok
            // 
            this.cmbCs�csok.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCs�csok.FormattingEnabled = true;
            this.cmbCs�csok.Location = new System.Drawing.Point(15, 37);
            this.cmbCs�csok.MaxLength = 1;
            this.cmbCs�csok.Name = "cmbCs�csok";
            this.cmbCs�csok.Size = new System.Drawing.Size(121, 21);
            this.cmbCs�csok.TabIndex = 1;
            // 
            // btnKezdBej�r�st
            // 
            this.btnKezdBej�r�st.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnKezdBej�r�st.Location = new System.Drawing.Point(15, 80);
            this.btnKezdBej�r�st.Name = "btnKezdBej�r�st";
            this.btnKezdBej�r�st.Size = new System.Drawing.Size(121, 43);
            this.btnKezdBej�r�st.TabIndex = 2;
            this.btnKezdBej�r�st.Text = "Sz�less�gi bej�r�s ind�t�sa";
            this.btnKezdBej�r�st.UseVisualStyleBackColor = true;
            this.btnKezdBej�r�st.Click += new System.EventHandler(this.KezdBej�r�st_Click);
            // 
            // button2
            // 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(150, 80);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(121, 43);
            this.button2.TabIndex = 3;
            this.button2.Text = "M�gsem";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // KezdoValasztoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 147);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnKezdBej�r�st);
            this.Controls.Add(this.cmbCs�csok);
            this.Controls.Add(this.label1);
            this.Name = "KezdoValasztoForm";
            this.Text = "Els� cs�cs";
            this.Load += new System.EventHandler(this.KezdoValasztoForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbCs�csok;
        private System.Windows.Forms.Button btnKezdBej�r�st;
        private System.Windows.Forms.Button button2;
    }
}