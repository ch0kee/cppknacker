using System;
using System.Windows.Forms;
using System.Threading;

namespace GrafSzelBe
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        Graf m_Gr�f = new Graf();
        //////////////////////////////////////////////////////////////////////////
        // Gr�f adatainak bet�lt�se
        private void gr�fAdatainakBet�lt�seToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog of = new OpenFileDialog();
            of.Filter = "Gr�f adatait tartalmaz� sz�vegf�jl (*.*)|*.*";
            of.Title = "Gr�f adatainak bet�lt�se";
            of.CheckPathExists = true;
            of.CheckFileExists = true;
            if (of.ShowDialog() == DialogResult.OK)
            {
                sz�less�giBej�r�sToolStripMenuItem.Enabled = m_Gr�f.Bet�ltGr�fot(of.FileName, pictureBox1, statusBar);
            }

        }
        //////////////////////////////////////////////////////////////////////////
        // Rajzdoboz OnPaint
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            m_Gr�f.RajzolCs�csokat(e);
        }
        //////////////////////////////////////////////////////////////////////////
        // Sz�less�gi bej�r�s
        private void sz�less�giBej�r�sToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StarterForm bej�r�s = new StarterForm(m_Gr�f.Cs�csok);
            if (bej�r�s.ShowDialog() == DialogResult.OK)
                ThreadPool.QueueUserWorkItem(new WaitCallback(m_Gr�f.Sz�less�giBej�r�s), bej�r�s);
        }

    }
}