#ifndef _BERLETFORM_H
#define _BERLETFORM_H

#include <QDialog>
#include <QWidget>
#include "ui_BerletForm.h"
#include "FitnessHandler.h"

class BerletForm : public QDialog, private Ui_BerletForm
{
	Q_OBJECT
public:
	BerletForm( FitnessHandler &fh, QWidget *parent = 0 );
public slots:
	void	slotHandleSelection();
	void	slotRemoveService();
	void	slotAddNewService();
	void	slotDeleteCustomer();
	
	void	slotCancel();
	void	slotSaveCurrent();
	void	slotSaveAndClose();
	
	void	slotIdentifierChanged(int index);

private:
	FitnessHandler		&m_FH;
};

#endif //_BERLETFORM_H

