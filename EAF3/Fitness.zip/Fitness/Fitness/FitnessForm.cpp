#include "FitnessForm.h"
#include "BerletForm.h"
#include <QFileDialog>
#include <QString>



FitnessForm::FitnessForm( QWidget *parent )
	: QMainWindow(parent)
{
	setupUi( this );
// menü
	connect(actAdatbazisBetoltese,	SIGNAL(triggered()), this, SLOT(slotLoadDataBase()));
	connect(actBerletekKezelese,	SIGNAL(triggered()), this, SLOT(slotShowBerletForm()));
	connect(actKilepes,				SIGNAL(triggered()), this, SLOT(close()));
}

void	FitnessForm::slotShowBerletForm()
{
	BerletForm	*form = new BerletForm( m_FH, this );
	form->show();
}

void	FitnessForm::slotLoadDataBase()
{
	 QString filename = QFileDialog::getOpenFileName(this,
     tr("Adatbázis megnyitása"), "/home", tr("Fitness adatbázisfájl (*.fdb)"));
     if (!filename.isNull())
     {
     	const bool SUCCESS = m_FH.LoadDBFile(true, filename );
     	statusBar()->showMessage( tr("Adatbázisfile betöltése ") + (SUCCESS ? tr("sikeres") : tr("sikertelen")),5000 );
     	actBerletekKezelese->setEnabled( SUCCESS );
     }
}

