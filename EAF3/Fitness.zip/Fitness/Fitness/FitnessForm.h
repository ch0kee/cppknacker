#ifndef _FITNESSFORM_H
#define _FITNESSFORM_H

#include <QMainWindow>
#include <QWidget>
#include "ui_MainForm.h"
#include "FitnessHandler.h"

class FitnessForm : public QMainWindow, private Ui_MainForm
{
	Q_OBJECT
public slots:
	void	slotShowBerletForm();
	void	slotLoadDataBase();
public:
	FitnessForm( QWidget *parent = 0 );
private:
	FitnessHandler		m_FH;
};

#endif //_FITNESSFORM_H

