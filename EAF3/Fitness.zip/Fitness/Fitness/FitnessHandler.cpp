#include "FitnessHandler.h"
#include <QComboBox>
#include <QTextStream>
#include "BerletForm.h"
#include <QMessageBox>

/////////////////////////////////////////////////////////
// Tokenizer
const QString 	FTok::END_ = "=FDB=END";
const QString	FTok::SERVICE_ = "=FDB=SERVICE";
const QString 	FTok::CUSTOMER_ = "=FDB=CUSTOMER";
FTok::Token	FTok::m_LastToken = FAILED;
void FTok::TokenizeIt( const QString& value )
{
	m_LastToken = 	(value == END_ ? End :
					(value == SERVICE_ ? Service :
					(value == CUSTOMER_ ? Customer : FAILED ) ) );
}
/////////////////////////////////////////////
// FitnessHandler
// ctr
FitnessHandler::FitnessHandler()
{}
// dtr
FitnessHandler::~FitnessHandler()
{
	ResetCustomersList();
}
/////////////////////////////////////////////
// adatbázis betöltése fájlból
bool FitnessHandler::LoadDBFile(bool newload, const QString& filename)
{
	ResetCustomersList();
	if (newload)
		m_FileIO.setFileName(filename);	
	const bool SUCCESS = m_FileIO.open(QIODevice::ReadOnly | QIODevice::Text);
	if (SUCCESS)
	{
		QTextStream in(&m_FileIO);
		FTok::TokenizeIt("");	// inicializálás FAILED-re
		// fájl végéig ciklus	
		while(!in.atEnd())
		{
			FTok::TokenizeIt( in.readLine() );
			if (FTok::LastTokenIs(FTok::Service))
				readService( in );
			else if (FTok::LastTokenIs(FTok::Customer))
				readCustomer( in );			
		}
		
	}
	return SUCCESS;
}
/////////////////////////////////////////////
// adatbázis elmentése fájlba
bool	FitnessHandler::SaveDBFile()
{
	if (m_FileIO.isOpen())
		m_FileIO.close();
	QFile::remove(m_FileIO.fileName());
	const bool SUCCESS = m_FileIO.open(QIODevice::WriteOnly | QIODevice::Text);
	if (SUCCESS)
	{
		QTextStream out(&m_FileIO);
		// szolgáltatások kiírása
		for(int i = 0; i < m_AvailableServices.size(); ++i)
		{
			out << FTok::SERVICE_ << '\n';
			out << m_AvailableServices[i].GetID() << '\n';
			out << m_AvailableServices[i].GetTitle() << '\n';
			out << m_AvailableServices[i].GetValue() << '\n';
		}
		// ügyfelek kiírása
		for(int i = 0; i < m_DB.GetCustomersCount(); ++i)
		{
			out << FTok::CUSTOMER_ << '\n';
			Customer	*Cust = m_DB.GetCustomerAt(i);
			out << Cust->GetID() << '\n';
			out << Cust->GetName() << '\n';
			out << Cust->GetPaidValue() << '\n';
			for(int j = 0; j < Cust->GetServicesCount(); ++j)	// szolgáltatások
				out << Cust->GetServiceIDAt(j) << ';' << Cust->GetDateAt(j) << '\n';
			out << FTok::END_ << '\n';			
		}		
	}
	return SUCCESS;
}
/////////////////////////////////////////////
// ügyfél hozzáadása fájlfolyamból
void	FitnessHandler::readCustomer( QTextStream &ts )
{
		int		id 		= ts.readLine().toInt();
		QString	name 	= ts.readLine();
		int		paidval	= ts.readLine().toInt();
		Customer* newCustomer = GetCustomerByID( id ) ? 0 : AddCustomer(id, name, paidval);
		while(!ts.atEnd())	// szolgáltatások
		{
			QString line = ts.readLine();
			FTok::TokenizeIt( line );
			if (!FTok::LastTokenIs(FTok::End))
			{
				if (newCustomer)
				{	// ha új az ügyfél (fel kell venni)
					QStringList parts = line.split(';');
					if (parts.size() == 2)
					{
						newCustomer->AddService(parts[0].toInt(), parts[1]);
					}
				}
			}
			else
				return;
		}
}
/////////////////////////////////////////////
// szolgáltatás beolvasása a fájlfolyamból
void	FitnessHandler::readService( QTextStream &ts )
{
		int		id 		= ts.readLine().toInt();
		QString	title 	= ts.readLine();
		int		value 	= ts.readLine().toInt();
		
		bool found = false;
		for(int i = 0; !found && i < m_AvailableServices.size(); ++i)
			found = m_AvailableServices[i].GetID() == id;
		if (!found)
			m_AvailableServices.append(Service(title, value, id));		
}
/////////////////////////////////////////////
// új ügyfél létrehozása és IDjének visszaadása
int		FitnessHandler::CreateNewCustomer()
{
	int id = GetNextFreeID();
	AddCustomer(id);
	return 	id;
}
/////////////////////////////////////////////
// ügyfélválasztó combobox betöltése
void	FitnessHandler::LoadCustomers( Ui_BerletForm* bform )
{
	bform->cmbIdentifier->clear();
	for(int i = 0; i < m_DB.GetCustomersCount(); ++i)
		bform->cmbIdentifier->addItem( QString("%1").arg(m_DB.GetCustomerAt(i)->GetID()) );	
	// hozzáadjuk az új ügyfél létrehozását segítő mezőt is
	bform->cmbIdentifier->addItem( "<Uj ugyfel>" );
}

/////////////////////////////////////////////
// aktuális ügyfél adatainak mentése
void	FitnessHandler::SaveCurrentCustomer( Ui_BerletForm* bform )
{
	if (Customer* cust = GetCustomerByID (bform->cmbIdentifier->currentText().toInt()))
	{
		cust->ClearServices();
		for(int i = 0; i < bform->tblUsedServices->rowCount(); ++i)
			if (Service	*serv = GetServiceByTitle(bform->tblUsedServices->item(i,0)->text()))
			{
				QString Date = bform->tblUsedServices->item(i,2)->text();
				cust->AddService(serv->GetID(), Date);
			}
		cust->SetName( bform->txtName->text() );
		if (bform->numPaidValue->value() != cust->GetPaidValue()
								&&	QMessageBox::question ( 0, "Bérleti díj változás",
								"Biztosan megváltoztatod a bérleti díjat ?",
								QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes)
			cust->SetPaidValue( bform->numPaidValue->value() );
	}
}
/////////////////////////////////////////////
// form kitöltése (id-t kivéve)
void	FitnessHandler::LoadCurrentCustomer( Ui_BerletForm* bform )
{
	Customer	*cust = GetCustomerByID( bform->cmbIdentifier->currentText().toInt() );
	// név
	bform->txtName->setText( cust ? cust->GetName() : "" );
	// fizetett
	bform->numPaidValue->setValue( cust ? cust->GetPaidValue() : 0);
	// használt szolgáltatások
	bform->tblUsedServices->setRowCount(cust ? cust->GetServicesCount() : 0);
	for(int i = 0; cust && i < cust->GetServicesCount(); ++i)
	{
		if (Service	*serv = GetServiceByID(cust->GetServiceIDAt(i)))
		{
			QString date = cust->GetDateAt(i);
			bform->tblUsedServices->setItem(i,0, new QTableWidgetItem(serv->GetTitle()));
			bform->tblUsedServices->setItem(i,1, new QTableWidgetItem(QString("%1 Ft").arg(serv->GetValue())));
			bform->tblUsedServices->setItem(i,2, new QTableWidgetItem(date));
		}
		else
			for (int j = 0; j < 3; ++j)
				bform->tblUsedServices->setItem(i,j, new QTableWidgetItem("---"));
		
	}
	// szolgáltatások
	bform->cmbServices->clear();
	for(int i = 0; cust && i < m_AvailableServices.size(); ++i)
		bform->cmbServices->addItem( m_AvailableServices[i].GetTitle() );
	// maradék összeg
	bform->lblRestValue->setText( cust ? GetRemainingHUFValue(cust) : "" );
}
/////////////////////////////////////////////
// szolgáltatás lekérdezése id alapján
Service*	FitnessHandler::GetServiceByID( int id )
{
		for(int i = 0; i < m_AvailableServices.size(); ++i)
			if (m_AvailableServices[i].GetID() == id)
				return &m_AvailableServices[i];
		return 0;
}
/////////////////////////////////////////////
// név alapján
Service*	FitnessHandler::GetServiceByTitle( QString title )
{
		for(int i = 0; i < m_AvailableServices.size(); ++i)
			if (m_AvailableServices[i].GetTitle() == title)
				return &m_AvailableServices[i];
		return 0;
}
/////////////////////////////////////////////
// aktuális vevő
Customer*	FitnessHandler::GetCustomerByID(int id)
{
	for(int i = 0; i < m_DB.GetCustomersCount(); ++i)
	{
		if (m_DB.GetCustomerAt(i)->GetID() == id)
			return m_DB.GetCustomerAt(i);
	}
	return 0;
}
/////////////////////////////////////////////
// maradék pénz kiszámolása
QString	FitnessHandler::GetRemainingHUFValue(Customer*& cust)
{
	return QString("%1 Ft").arg(GetRemainingVal(cust));
}
int		FitnessHandler::GetRemainingVal(Customer*& cust)
{
	int remaining_value = cust->GetPaidValue();
	for (int i = 0; i < cust->GetServicesCount(); ++i)
	{	// levonjuk a szolgáltatások árát
		int serviceindex = cust->GetServiceIDAt(i);
		remaining_value -= m_AvailableServices[serviceindex].GetValue();
	}
	return remaining_value;
}
/////////////////////////////////////////////
// biztosan legyen bezárva a file és üres legyen a lista
void FitnessHandler::ResetCustomersList()
{
	if (m_FileIO.isOpen())
		m_FileIO.close();
	m_DB.ClearAllData();
}
/////////////////////////////////////////////
// következő szabad azonosító
int			FitnessHandler::GetNextFreeID()
{
	if (m_DB.GetCustomersCount() == 0)
		return 1;
	int max = m_DB.GetCustomerAt(0)->GetID();
	for(int i = 1; i < m_DB.GetCustomersCount(); ++i)
		if (m_DB.GetCustomerAt(i)->GetID() > max)
			max = m_DB.GetCustomerAt(i)->GetID();
	return max+1;
}
/////////////////////////////////////////////
// ügyfél törlése id alapján
void		FitnessHandler::RemoveCustomer( int id )
{
	if (id == -1)
		return;
	for(int i = 0; i < m_DB.GetCustomersCount(); ++i)
		if (m_DB.GetCustomerAt(i)->GetID() == id)
		{
			m_DB.RemoveCustomerAt(i);
			return;
		}
}
/////////////////////////////////////////////
// ügyfél hozzáadása
Customer*	FitnessHandler::AddCustomer(int id, QString name, int paid)
{
	return m_DB.AppendCustomer(Customer(id,name,paid));
}

