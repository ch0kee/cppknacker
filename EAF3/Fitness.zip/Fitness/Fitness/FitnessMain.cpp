#include <QApplication>
#include "FitnessForm.h"

int main( int argc, char* argv[] )
{
	QApplication	app(argc, argv);
	
	FitnessForm	*form = new FitnessForm();
	form->show();
	
	return app.exec();
}
