#include "DataBase.h"

///////////////////////////////////////////////////
// Service
//ctr
Service::Service(QString title, int val, int id)
	: m_Title(title), m_Value(val), m_ID(id)
{}
///////////////////////////////////////////////////
// Customer
// ctr
Customer::Customer(int id, QString name, int paid)
	: m_ID(id), m_Name(name), m_PaidValue(paid)
{}
// dtr
Customer::~Customer()
{}
// szolgáltatások törlése
void	Customer::ClearServices()
{
	m_Services.clear();
}
// adott szolgáltatás eltávolítása
void	Customer::RemoveService( int id, QString date )
{
	for(int i = 0; i < m_Dates.size(); ++i)
	{
		if (m_Dates[i] == date && m_Services[i] == id)
		{
			m_Dates.remove(i);
			m_Services.remove(i);
			return;
		}
			
	}
}
///////////////////////////////////////////////////
// DataBase
// ctr
DataBase::DataBase()
{}
// dtr
DataBase::~DataBase()
{
	ClearAllData();
}
// ügyfelek törlése
void	DataBase::ClearAllData()
{
	m_Customers.clear();
}

