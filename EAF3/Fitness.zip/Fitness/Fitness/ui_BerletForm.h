/********************************************************************************
** Form generated from reading ui file 'BerletForm.ui'
**
** Created: Fri May 16 14:25:39 2008
**      by: Qt User Interface Compiler version 4.3.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_BERLETFORM_H
#define UI_BERLETFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QSpinBox>
#include <QtGui/QTableWidget>
#include <QtGui/QToolButton>
#include <QtGui/QVBoxLayout>

class Ui_BerletForm
{
public:
    QVBoxLayout *vboxLayout;
    QGroupBox *groupBox;
    QVBoxLayout *vboxLayout1;
    QGridLayout *gridLayout;
    QLabel *label;
    QComboBox *cmbIdentifier;
    QToolButton *btnDelCustomer;
    QLabel *label_2;
    QLineEdit *txtName;
    QGroupBox *groupBox_2;
    QVBoxLayout *vboxLayout2;
    QHBoxLayout *hboxLayout;
    QLabel *label_3;
    QSpinBox *numPaidValue;
    QVBoxLayout *vboxLayout3;
    QLabel *label_5;
    QTableWidget *tblUsedServices;
    QHBoxLayout *hboxLayout1;
    QLabel *label_6;
    QLabel *lblRestValue;
    QHBoxLayout *hboxLayout2;
    QPushButton *btnNewService;
    QComboBox *cmbServices;
    QSpacerItem *spacerItem;
    QPushButton *btnRemoveService;
    QHBoxLayout *hboxLayout3;
    QPushButton *btnDone;
    QSpacerItem *spacerItem1;
    QPushButton *btnSaveCurrent;
    QPushButton *btnCancel;

    void setupUi(QDialog *BerletForm)
    {
    if (BerletForm->objectName().isEmpty())
        BerletForm->setObjectName(QString::fromUtf8("BerletForm"));
    BerletForm->setWindowModality(Qt::ApplicationModal);
    BerletForm->resize(516, 679);
    BerletForm->setModal(true);
    vboxLayout = new QVBoxLayout(BerletForm);
    vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
    groupBox = new QGroupBox(BerletForm);
    groupBox->setObjectName(QString::fromUtf8("groupBox"));
    vboxLayout1 = new QVBoxLayout(groupBox);
    vboxLayout1->setObjectName(QString::fromUtf8("vboxLayout1"));
    gridLayout = new QGridLayout();
    gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));

    gridLayout->addWidget(label, 0, 0, 1, 1);

    cmbIdentifier = new QComboBox(groupBox);
    cmbIdentifier->setObjectName(QString::fromUtf8("cmbIdentifier"));

    gridLayout->addWidget(cmbIdentifier, 0, 1, 1, 1);

    btnDelCustomer = new QToolButton(groupBox);
    btnDelCustomer->setObjectName(QString::fromUtf8("btnDelCustomer"));

    gridLayout->addWidget(btnDelCustomer, 0, 2, 1, 1);

    label_2 = new QLabel(groupBox);
    label_2->setObjectName(QString::fromUtf8("label_2"));

    gridLayout->addWidget(label_2, 1, 0, 1, 1);

    txtName = new QLineEdit(groupBox);
    txtName->setObjectName(QString::fromUtf8("txtName"));

    gridLayout->addWidget(txtName, 1, 1, 1, 2);


    vboxLayout1->addLayout(gridLayout);


    vboxLayout->addWidget(groupBox);

    groupBox_2 = new QGroupBox(BerletForm);
    groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
    vboxLayout2 = new QVBoxLayout(groupBox_2);
    vboxLayout2->setObjectName(QString::fromUtf8("vboxLayout2"));
    hboxLayout = new QHBoxLayout();
    hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
    label_3 = new QLabel(groupBox_2);
    label_3->setObjectName(QString::fromUtf8("label_3"));

    hboxLayout->addWidget(label_3);

    numPaidValue = new QSpinBox(groupBox_2);
    numPaidValue->setObjectName(QString::fromUtf8("numPaidValue"));
    numPaidValue->setMaximum(5000000);
    numPaidValue->setValue(0);

    hboxLayout->addWidget(numPaidValue);


    vboxLayout2->addLayout(hboxLayout);

    vboxLayout3 = new QVBoxLayout();
    vboxLayout3->setObjectName(QString::fromUtf8("vboxLayout3"));
    label_5 = new QLabel(groupBox_2);
    label_5->setObjectName(QString::fromUtf8("label_5"));

    vboxLayout3->addWidget(label_5);

    tblUsedServices = new QTableWidget(groupBox_2);
    tblUsedServices->setObjectName(QString::fromUtf8("tblUsedServices"));
    tblUsedServices->setEditTriggers(QAbstractItemView::NoEditTriggers);
    tblUsedServices->setSelectionMode(QAbstractItemView::SingleSelection);
    tblUsedServices->setSelectionBehavior(QAbstractItemView::SelectRows);

    vboxLayout3->addWidget(tblUsedServices);


    vboxLayout2->addLayout(vboxLayout3);

    hboxLayout1 = new QHBoxLayout();
    hboxLayout1->setObjectName(QString::fromUtf8("hboxLayout1"));
    label_6 = new QLabel(groupBox_2);
    label_6->setObjectName(QString::fromUtf8("label_6"));

    hboxLayout1->addWidget(label_6);

    lblRestValue = new QLabel(groupBox_2);
    lblRestValue->setObjectName(QString::fromUtf8("lblRestValue"));

    hboxLayout1->addWidget(lblRestValue);


    vboxLayout2->addLayout(hboxLayout1);

    hboxLayout2 = new QHBoxLayout();
    hboxLayout2->setObjectName(QString::fromUtf8("hboxLayout2"));
    btnNewService = new QPushButton(groupBox_2);
    btnNewService->setObjectName(QString::fromUtf8("btnNewService"));

    hboxLayout2->addWidget(btnNewService);

    cmbServices = new QComboBox(groupBox_2);
    cmbServices->setObjectName(QString::fromUtf8("cmbServices"));

    hboxLayout2->addWidget(cmbServices);

    spacerItem = new QSpacerItem(240, 30, QSizePolicy::Expanding, QSizePolicy::Minimum);

    hboxLayout2->addItem(spacerItem);

    btnRemoveService = new QPushButton(groupBox_2);
    btnRemoveService->setObjectName(QString::fromUtf8("btnRemoveService"));
    btnRemoveService->setEnabled(false);

    hboxLayout2->addWidget(btnRemoveService);


    vboxLayout2->addLayout(hboxLayout2);


    vboxLayout->addWidget(groupBox_2);

    hboxLayout3 = new QHBoxLayout();
    hboxLayout3->setObjectName(QString::fromUtf8("hboxLayout3"));
    btnDone = new QPushButton(BerletForm);
    btnDone->setObjectName(QString::fromUtf8("btnDone"));

    hboxLayout3->addWidget(btnDone);

    spacerItem1 = new QSpacerItem(324, 23, QSizePolicy::Expanding, QSizePolicy::Minimum);

    hboxLayout3->addItem(spacerItem1);

    btnSaveCurrent = new QPushButton(BerletForm);
    btnSaveCurrent->setObjectName(QString::fromUtf8("btnSaveCurrent"));

    hboxLayout3->addWidget(btnSaveCurrent);

    btnCancel = new QPushButton(BerletForm);
    btnCancel->setObjectName(QString::fromUtf8("btnCancel"));

    hboxLayout3->addWidget(btnCancel);


    vboxLayout->addLayout(hboxLayout3);


    retranslateUi(BerletForm);

    QMetaObject::connectSlotsByName(BerletForm);
    } // setupUi

    void retranslateUi(QDialog *BerletForm)
    {
    BerletForm->setWindowTitle(QApplication::translate("BerletForm", "B\303\251rletek kezel\303\251se", 0, QApplication::UnicodeUTF8));
    groupBox->setTitle(QApplication::translate("BerletForm", "\303\234gyf\303\251l", 0, QApplication::UnicodeUTF8));
    label->setText(QApplication::translate("BerletForm", "Azonos\303\255t\303\263", 0, QApplication::UnicodeUTF8));
    btnDelCustomer->setText(QApplication::translate("BerletForm", "X", 0, QApplication::UnicodeUTF8));
    label_2->setText(QApplication::translate("BerletForm", "N\303\251v", 0, QApplication::UnicodeUTF8));
    groupBox_2->setTitle(QApplication::translate("BerletForm", "B\303\251rlet", 0, QApplication::UnicodeUTF8));
    label_3->setText(QApplication::translate("BerletForm", "Befizetett b\303\251rleti d\303\255j :", 0, QApplication::UnicodeUTF8));
    numPaidValue->setSuffix(QApplication::translate("BerletForm", " Ft", 0, QApplication::UnicodeUTF8));
    label_5->setText(QApplication::translate("BerletForm", "Ig\303\251nybevett szolg\303\241ltat\303\241sok", 0, QApplication::UnicodeUTF8));
    if (tblUsedServices->columnCount() < 3)
        tblUsedServices->setColumnCount(3);

    QTableWidgetItem *__colItem = new QTableWidgetItem();
    __colItem->setText(QApplication::translate("BerletForm", "Megnevez\303\251s", 0, QApplication::UnicodeUTF8));
    tblUsedServices->setHorizontalHeaderItem(0, __colItem);

    QTableWidgetItem *__colItem1 = new QTableWidgetItem();
    __colItem1->setText(QApplication::translate("BerletForm", "\303\211rt\303\251k", 0, QApplication::UnicodeUTF8));
    tblUsedServices->setHorizontalHeaderItem(1, __colItem1);

    QTableWidgetItem *__colItem2 = new QTableWidgetItem();
    __colItem2->setText(QApplication::translate("BerletForm", "Ig\303\251nybev\303\251tel", 0, QApplication::UnicodeUTF8));
    tblUsedServices->setHorizontalHeaderItem(2, __colItem2);
    label_6->setText(QApplication::translate("BerletForm", "Felhaszn\303\241lhat\303\263 b\303\251rleti \303\266sszeg :", 0, QApplication::UnicodeUTF8));
    lblRestValue->setText(QApplication::translate("BerletForm", "xxx Ft", 0, QApplication::UnicodeUTF8));
    btnNewService->setText(QApplication::translate("BerletForm", "Hozz\303\241ad", 0, QApplication::UnicodeUTF8));
    btnRemoveService->setText(QApplication::translate("BerletForm", "T\303\266rl\303\251s", 0, QApplication::UnicodeUTF8));
    btnDone->setText(QApplication::translate("BerletForm", "K\303\251sz", 0, QApplication::UnicodeUTF8));
    btnSaveCurrent->setText(QApplication::translate("BerletForm", "Aktu\303\241lis lapot ment", 0, QApplication::UnicodeUTF8));
    btnCancel->setText(QApplication::translate("BerletForm", "M\303\251gsem", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(BerletForm);
    } // retranslateUi

};

namespace Ui {
    class BerletForm: public Ui_BerletForm {};
} // namespace Ui

#endif // UI_BERLETFORM_H
