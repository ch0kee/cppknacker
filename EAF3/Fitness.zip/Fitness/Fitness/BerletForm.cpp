#include "BerletForm.h"
#include <QList>
#include <QDate>
#include <QMainWindow>
#include <QStatusBar>
#include <QMessageBox>
/////////////////////////////////////////////////////////
// BerletForm
// ctr
BerletForm::BerletForm( FitnessHandler &fh, QWidget *parent )
	: QDialog(parent), m_FH(fh)
{
	setupUi( this );
	//
// ügyfelek combobox feltöltése
	m_FH.LoadCustomers( this );
	m_FH.LoadCurrentCustomer( this );
// mai dátum
	((QMainWindow*)parent)->statusBar()->showMessage( tr("Mai datum : ") + m_FH.GetTodaysDate() );
// eseménykezelők
	connect(cmbIdentifier, SIGNAL(activated (int)), this ,SLOT(slotIdentifierChanged(int)));
	connect(tblUsedServices, SIGNAL(itemSelectionChanged()), this ,SLOT(slotHandleSelection()));
	connect(btnRemoveService, SIGNAL(clicked()), this, SLOT(slotRemoveService()));
	connect(btnNewService, SIGNAL(clicked()), this, SLOT(slotAddNewService()));
	connect(btnDelCustomer, SIGNAL(clicked()), this, SLOT(slotDeleteCustomer()));
	
	connect(btnDone, SIGNAL(clicked()), this, SLOT(slotSaveAndClose()));
	connect(btnSaveCurrent, SIGNAL(clicked()), this, SLOT(slotSaveCurrent()));
	connect(btnCancel, SIGNAL(clicked()), this, SLOT(slotCancel()));
	
}
/////////////////////////////////////////////////////////
// aktuális szolgáltatás eltávolítása
void	BerletForm::slotRemoveService()
{
	QList<QTableWidgetItem *> selections = tblUsedServices->selectedItems ();
	if (selections.size() == 0)
		return;
	if (Customer* cust = m_FH.GetCustomerByID(cmbIdentifier->currentText().toInt()))
	{
		int 		selectedRow = selections[0]->row();
		QString		selectedService = tblUsedServices->item(selectedRow,0)->text();
		if (Service* serv = m_FH.GetServiceByTitle(selectedService))
		{
			cust->RemoveService(serv->GetID(), m_FH.GetTodaysDate());
			m_FH.LoadCurrentCustomer( this );
		}

	}
}
/////////////////////////////////////////////////////////
// új szolgáltatás hozzáadása
void	BerletForm::slotAddNewService()
{
	if (Service* serv = m_FH.GetServiceByTitle(cmbServices->currentText()))
	{
		if (Customer* cust = m_FH.GetCustomerByID(cmbIdentifier->currentText().toInt()))
		{
			if (m_FH.GetRemainingVal(cust) - serv->GetValue() >= 0)
			{
				cust->AddService(serv->GetID(), m_FH.GetTodaysDate());
				m_FH.LoadCurrentCustomer( this );
			}
			else
				QMessageBox::warning(0,"Érvénytelen igénylés","Az ügyfél nem rendelkezik elég kerettel");
		}
	}	
}
/////////////////////////////////////////////////////////
// aktuális ügyfél eltávolítása
void	BerletForm::slotDeleteCustomer()
{
	m_FH.RemoveCustomer( cmbIdentifier->currentText().toInt() );
	m_FH.LoadCustomers( this );
	m_FH.LoadCurrentCustomer( this );
}
/////////////////////////////////////////////////////////
// ügyfelet váltottunk
void	BerletForm::slotIdentifierChanged(int index)
{
	btnRemoveService->setEnabled( false );
	if (index != -1)
	{
		// megnézzük mire nyomott
		bool 	clickedOnNewCustomer = index == cmbIdentifier->count()-1;
		if (!clickedOnNewCustomer) // #LÉTEZŐ ÜGYFÉL
		{
			m_FH.LoadCurrentCustomer( this );
		}
		else // #ÚJ ÜGYFÉL
		{
			int id = m_FH.CreateNewCustomer();
			cmbIdentifier->setItemText( cmbIdentifier->count()-1, QString("%1").arg(id) );
			cmbIdentifier->addItem( "<Uj ugyfel>" );
			m_FH.LoadCurrentCustomer( this );
		}
	}
}
/////////////////////////////////////////////////////////
// szolgáltatás kiválasztva
void	BerletForm::slotHandleSelection()
{
	QList<QTableWidgetItem *> selections = tblUsedServices->selectedItems ();
	if (selections.size() == 0)
		return;
	int selectedrow = selections[0]->row();
	const bool Editable (tblUsedServices->item(selectedrow,2)->text() == m_FH.GetTodaysDate());
	btnRemoveService->setEnabled( Editable );
}
/////////////////////////////////////////////////////////
// elment és bezár
void	BerletForm::slotSaveAndClose()
{
	m_FH.SaveDBFile();
	close();
}
/////////////////////////////////////////////////////////
// csak bezár mentés nélkül
void	BerletForm::slotCancel()
{
	// nem mentjük el, csak újra betöltjük a filet
	m_FH.LoadDBFile();
	close();	
}
/////////////////////////////////////////////////////////
// aktuális lap frissítése
void	BerletForm::slotSaveCurrent()
{
	m_FH.SaveCurrentCustomer( this );
	m_FH.LoadCurrentCustomer( this );
}

