#ifndef _DATABASE_H
#define _DATABASE_H

#include <QString>
#include <QVector>

///////////////////////////////////////////////////////
// szolgáltatás
class Service
{
public:
	Service(QString title = "", int val = 0, int id = 0);
	QString			GetTitle() const { return m_Title; }
	int				GetValue() const { return m_Value; }
	int				GetID() const { return m_ID; }
private:
	QString			m_Title;	// megnevezés
	int				m_Value;	// érték (HUF)
	int				m_ID;
};
///////////////////////////////////////////////////////
// ügyfél
class Customer
{
public:
	Customer(int id = 0, QString name = "", int paid = 0);
	~Customer();
	// listakezelés
	void		AddService(int serviceid, QString date) { m_Services.append(serviceid); m_Dates.append(date); }
	void		RemoveService( int id, QString date );
	void		ClearServices();
	// lekérdezések és beírások
	void		SetName(QString name)  { m_Name = name; }
	void		SetPaidValue(int val)  { m_PaidValue = val; }
	int			GetID() const { return m_ID; }
	QString		GetName() const { return m_Name; }
	int			GetPaidValue() const { return m_PaidValue; }
	// szolgáltatások	
	int			GetServicesCount() const { return m_Services.size(); }
	int			GetServiceIDAt(int index) { return m_Services[index]; }
	QString		GetDateAt(int index) { return m_Dates[index]; }
private:
	int					m_ID;		// azonosító
	QString				m_Name;		// név
	int					m_PaidValue;// kifizetett bérletidíj
	QVector<int>		m_Services;	// megrendelt szolgáltatások azonosítói
	QVector<QString>	m_Dates;	// szolgáltatások dátumai
};
///////////////////////////////////////////////////////
// ügyféllista kezelő
class DataBase
{
public:
	DataBase();
	~DataBase();
	// listakezelés

	void		ClearAllData();
	// ügyfelek	
	int			GetCustomersCount() const { return m_Customers.size(); }
	Customer*	GetCustomerAt(int index) { return &m_Customers[index]; }
	void		RemoveCustomerAt( int index ) { m_Customers.remove(index); }
	Customer*	AppendCustomer(const Customer &cust) { m_Customers.append(cust); return &m_Customers.last(); }
	
private:
	QVector<Customer>	m_Customers;// ügyfelek listája
};

#endif //_DATABASE_H
