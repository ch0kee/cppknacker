/********************************************************************************
** Form generated from reading ui file 'MainForm.ui'
**
** Created: Fri May 16 05:54:17 2008
**      by: Qt User Interface Compiler version 4.3.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_MAINFORM_H
#define UI_MAINFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QWidget>

class Ui_MainForm
{
public:
    QAction *actBerletekKezelese;
    QAction *actAdatbazisBetoltese;
    QAction *actKilepes;
    QWidget *centralwidget;
    QMenuBar *menubar;
    QMenu *menuFajl;
    QMenu *menuBerlet;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainForm)
    {
    if (MainForm->objectName().isEmpty())
        MainForm->setObjectName(QString::fromUtf8("MainForm"));
    MainForm->setWindowModality(Qt::ApplicationModal);
    MainForm->resize(800, 600);
    actBerletekKezelese = new QAction(MainForm);
    actBerletekKezelese->setObjectName(QString::fromUtf8("actBerletekKezelese"));
    actBerletekKezelese->setEnabled(false);
    actAdatbazisBetoltese = new QAction(MainForm);
    actAdatbazisBetoltese->setObjectName(QString::fromUtf8("actAdatbazisBetoltese"));
    actKilepes = new QAction(MainForm);
    actKilepes->setObjectName(QString::fromUtf8("actKilepes"));
    centralwidget = new QWidget(MainForm);
    centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
    MainForm->setCentralWidget(centralwidget);
    menubar = new QMenuBar(MainForm);
    menubar->setObjectName(QString::fromUtf8("menubar"));
    menubar->setGeometry(QRect(0, 0, 800, 25));
    menuFajl = new QMenu(menubar);
    menuFajl->setObjectName(QString::fromUtf8("menuFajl"));
    menuBerlet = new QMenu(menubar);
    menuBerlet->setObjectName(QString::fromUtf8("menuBerlet"));
    MainForm->setMenuBar(menubar);
    statusbar = new QStatusBar(MainForm);
    statusbar->setObjectName(QString::fromUtf8("statusbar"));
    MainForm->setStatusBar(statusbar);

    menubar->addAction(menuFajl->menuAction());
    menubar->addAction(menuBerlet->menuAction());
    menuFajl->addAction(actAdatbazisBetoltese);
    menuFajl->addAction(actKilepes);
    menuBerlet->addAction(actBerletekKezelese);

    retranslateUi(MainForm);

    QMetaObject::connectSlotsByName(MainForm);
    } // setupUi

    void retranslateUi(QMainWindow *MainForm)
    {
    MainForm->setWindowTitle(QApplication::translate("MainForm", "Fitnessb\303\251rlet-kezel\305\221 alkalmaz\303\241s", 0, QApplication::UnicodeUTF8));
    actBerletekKezelese->setText(QApplication::translate("MainForm", "B\303\251rletek kezel\303\251se...", 0, QApplication::UnicodeUTF8));
    actAdatbazisBetoltese->setText(QApplication::translate("MainForm", "Adatb\303\241zis bet\303\266lt\303\251se...", 0, QApplication::UnicodeUTF8));
    actKilepes->setText(QApplication::translate("MainForm", "Kil\303\251p\303\251s", 0, QApplication::UnicodeUTF8));
    menuFajl->setTitle(QApplication::translate("MainForm", "F\303\241jl", 0, QApplication::UnicodeUTF8));
    menuBerlet->setTitle(QApplication::translate("MainForm", "B\303\251rlet", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainForm: public Ui_MainForm {};
} // namespace Ui

#endif // UI_MAINFORM_H
