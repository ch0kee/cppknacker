// A Program Alkalmazáslogikai részéért felelős osztály

#ifndef _FITNESSHANDLER_H
#define _FITNESSHANDLER_H

#include "DataBase.h"
#include <QFile>
#include <QDate>

///////////////////////////////////////////////////////
// alkalmazáslogikai réteg kezelője
class QComboBox;
class Ui_BerletForm;
class QTextStream;
class FitnessHandler
{
public:
	FitnessHandler();
	~FitnessHandler();
	int			CreateNewCustomer();
	Customer*	AddCustomer(int id, QString name = "<nev>", int paid = 0);
	void		RemoveCustomer( int id );
	
	void		ChangeCurrentCustomer( int id, Ui_BerletForm* bform );
	
	void		LoadCurrentCustomer( Ui_BerletForm* bform );
	void		SaveCurrentCustomer( Ui_BerletForm* bform );
	void		LoadCustomers( Ui_BerletForm* bform );
	
	Service*	GetServiceByID( int id );
	Service*	GetServiceByTitle( QString title );
	Customer*	GetCustomerByID(int id);
	int			GetNextFreeID();
	
	bool	LoadDBFile(bool newload = false, const QString& filename = "");
	bool	SaveDBFile();
	
	void	ResetCustomersList();	
	
	void	readCustomer( QTextStream &ts );
	void	readService( QTextStream &ts );
	
	QString	GetRemainingHUFValue(Customer*& cust);
	int		GetRemainingVal(Customer*& cust);
	QString	GetTodaysDate() const { return QDate::currentDate().toString("yyyyMMdd"); }
private:
	QFile					m_FileIO;	
	QVector<Service>		m_AvailableServices;	// választható szolgáltatások
	DataBase				m_DB;
};
///////////////////////////////////////////////////////
// Fájlfeldolgozó
class FTok
{

public:
	enum Token { Begin, End, Service, Customer, FAILED };
	static void 	TokenizeIt( const QString& value );
	static bool 	LastTokenIs( Token t ) { return m_LastToken == t; }
	//static QString	LastLine() { return m_LastLine; }
	static const QString BEGIN_;
	static const QString END_;
	static const QString SERVICE_;
	static const QString CUSTOMER_;	
private:
	static Token	m_LastToken;
	static QString	m_LastLine;
};

#endif //_FITNESSHANDLER_H
