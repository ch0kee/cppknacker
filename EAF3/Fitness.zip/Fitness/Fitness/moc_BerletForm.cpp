/****************************************************************************
** Meta object code from reading C++ file 'BerletForm.h'
**
** Created: Fri May 16 15:48:54 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "BerletForm.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'BerletForm.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_BerletForm[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x0a,
      34,   11,   11,   11, 0x0a,
      54,   11,   11,   11, 0x0a,
      74,   11,   11,   11, 0x0a,
      95,   11,   11,   11, 0x0a,
     108,   11,   11,   11, 0x0a,
     126,   11,   11,   11, 0x0a,
     151,  145,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_BerletForm[] = {
    "BerletForm\0\0slotHandleSelection()\0"
    "slotRemoveService()\0slotAddNewService()\0"
    "slotDeleteCustomer()\0slotCancel()\0"
    "slotSaveCurrent()\0slotSaveAndClose()\0"
    "index\0slotIdentifierChanged(int)\0"
};

const QMetaObject BerletForm::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_BerletForm,
      qt_meta_data_BerletForm, 0 }
};

const QMetaObject *BerletForm::metaObject() const
{
    return &staticMetaObject;
}

void *BerletForm::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_BerletForm))
	return static_cast<void*>(const_cast< BerletForm*>(this));
    return QDialog::qt_metacast(_clname);
}

int BerletForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: slotHandleSelection(); break;
        case 1: slotRemoveService(); break;
        case 2: slotAddNewService(); break;
        case 3: slotDeleteCustomer(); break;
        case 4: slotCancel(); break;
        case 5: slotSaveCurrent(); break;
        case 6: slotSaveAndClose(); break;
        case 7: slotIdentifierChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        }
        _id -= 8;
    }
    return _id;
}
